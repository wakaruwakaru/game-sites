import PubSub from 'pubsub-js'

// PubSub.subscribe('x', (msg, data) => console.log(msg, data))

export default PubSub
