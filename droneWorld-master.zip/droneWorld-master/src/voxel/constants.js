const voxelSize = 500
const voxelLayers = 2
const voxelNumber = 3
const voxelOffset = {
  x: 0, y: 0, z: -175
}

export {
  voxelSize,
  voxelLayers,
  voxelNumber,
  voxelOffset
}
