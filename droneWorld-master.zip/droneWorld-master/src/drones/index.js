import loadDroneAssets from './loader'
import './init'

export default loadDroneAssets
